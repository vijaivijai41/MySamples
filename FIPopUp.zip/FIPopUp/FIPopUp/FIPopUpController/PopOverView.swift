//
//  PopOverView.swift
//  FIPopUp
//
//  Created by Vijay on 09/11/20.
//

import Foundation
import UIKit


class PopOverView: UIView {
    
    lazy var popOverBaseView: UIView = {
        let baseView = UIView()
        baseView.backgroundColor = UIColor.red
        baseView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        return baseView
    }()
    
    lazy var customTableView: UITableView = {
        let table = UITableView(frame: self.bounds)
        table.delegate = self
        table.dataSource = self
        table.backgroundColor = .blue
        self.addSubview(table)
        return table
    }()
    
    var targetView: UIView?
    var fromView: UIView?
    var contentSize: CGSize?
    var arrayObjects: [[String: String]] = [["title": "One time", "image":"onetime"],["title": "SIP", "image":"sip"],["title": "Goal", "image":"goal"]]
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.customTableView.register(UINib(nibName: "PopupTableViewCell", bundle: nil), forCellReuseIdentifier: "PopupTableViewCell")

    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    convenience init(contentSize: CGSize,isBarbutton: Bool ,fromView: UIView?, targetView: UIView?) {
        let xAxis = UIView.convertXoriginPoint(view: fromView, contentSize: contentSize)
        
        let yAsis = (isBarbutton == true) ? (fromView?.frame.origin.y ?? 0) : UIView.convertYoriginPoint(view: fromView, contentSize: contentSize)
        
        self.init(frame: CGRect(x: xAxis , y: yAsis, width: contentSize.width, height: contentSize.height))
        self.fromView = fromView
        self.targetView = targetView
        self.contentSize = contentSize
        
    }
    
    static func showPopUpView(fromView: UIView?, targetView: UIView,isBarbutton: Bool ,contentSize: CGSize) {
        let popUp = PopOverView(contentSize: contentSize, isBarbutton: isBarbutton, fromView: fromView, targetView: targetView)
        popUp.tag = 1904974
        popUp.backgroundColor = .red
        if let popUpView = targetView.subviews.filter(
            { $0.tag == 1904974}).first {
            
            popUpView.fadeOut()
            
        } else {
            popUp.alpha = 0
            popUp.isHidden = false
            popUp.addSubview(popUp.customTableView)
            targetView.addSubview(popUp)
            popUp.fadeIn()
        }
    }
    
}


extension PopOverView: UITableViewDelegate, UITableViewDataSource {

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayObjects.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PopupTableViewCell", for: indexPath) as! PopupTableViewCell
        cell.nameLabel.text = arrayObjects[indexPath.row]["title"]
        return cell
    }
}


