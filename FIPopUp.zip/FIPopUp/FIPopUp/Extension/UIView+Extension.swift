//
//  UIView+Extension.swift
//  FIPopUp
//
//  Created by Vijay on 09/11/20.
//

import Foundation
import UIKit
 

extension UIView {
    
    static var screenHeight: CGFloat {
        return UIScreen.main.bounds.size.height
    }
    
    static var screenWidth: CGFloat {
        return UIScreen.main.bounds.size.width
    }
    
    static func convertXoriginPoint(view: UIView?, contentSize: CGSize) -> CGFloat {
        if (view?.center.x ?? 0) + contentSize.width > UIView.screenWidth {
            return UIView.screenWidth - contentSize.width
        } else {
            return ((view?.center.x ?? 0) - contentSize.width/2 > 0) ?  (view?.center.x ?? 0) - contentSize.width/2 : 0
        }
    }
    
    static func convertYoriginPoint(view: UIView?, contentSize: CGSize) -> CGFloat {
        if (view?.center.y ?? 0) + (view?.frame.size.height ?? 0) + contentSize.height > UIView.screenHeight {
            return (view?.center.y ?? 0) - (view?.frame.size.height ?? 0)/2 - contentSize.height
        } else {
            return (view?.frame.maxY ?? 0)
        }
    }
    
    
    func fadeIn(duration: TimeInterval = 0.5,
                delay: TimeInterval = 0.0,
                completion: @escaping ((Bool) -> Void) = {(finished: Bool) -> Void in }) {
      UIView.animate(withDuration: duration,
                     delay: delay,
                     options: .curveEaseOut,
                     animations: {
        self.alpha = 1.0
      }, completion: completion)
    }

    func fadeOut(duration: TimeInterval = 0.5,
                 delay: TimeInterval = 0.0,
                 completion: @escaping (Bool) -> Void = {(finished: Bool) -> Void in }) {
      
      UIView.animate(withDuration: duration, delay: delay, options: .curveEaseOut) {
          self.alpha = 0.0
      } completion: { _ in
          self.removeFromSuperview()
      }
    }
}





