//
//  ViewController.swift
//  FIPopUp
//
//  Created by Vijay on 09/11/20.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var rightButton: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonDidTap(_ sender: UIButton) {
        
        PopOverView.showPopUpView(fromView: sender, targetView: self.view, isBarbutton: false, contentSize: CGSize(width: 200, height: 100))
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let showController = storyboard.instantiateViewController(withIdentifier: "ShowViewController") as! ShowViewController
//        showController.showPopUp(fromController: self,fromView: sender, barButton: nil, contentSize: CGSize(width: 200, height: 200))
    }
    @IBAction func barbuttonAction(_ sender: UIBarButtonItem) {
        if let view = self.fetchExactView(barbutton: sender) {
            PopOverView.showPopUpView(fromView: view, targetView: self.view, isBarbutton: true, contentSize: CGSize(width: 200, height: 200))
        }
    }
    
}



extension UIBarButtonItem {
    var view: UIView? {
        return perform(#selector(getter: UIViewController.view)).takeRetainedValue() as? UIView
    }
    
}

