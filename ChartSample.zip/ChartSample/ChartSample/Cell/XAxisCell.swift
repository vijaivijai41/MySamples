//
//  XAxisCell.swift
//  ChartSample
//
//  Created by Vijay on 25/06/21.
//

import UIKit

class XAxisCell: UICollectionViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
