//
//  ChartView.swift
//  ChartSample
//
//  Created by Vijay on 25/06/21.
//

import Foundation
import UIKit

enum GraphDataPoint {
    case xValue
    case yValue
    case infoValue
}

struct GraphSet {
    let colors: UIColor
    let data: [Int]
    let graphDataPoint: GraphDataPoint
}

struct ChartDataModel {
    let xValue: GraphSet
    let yValue: GraphSet
    let infoValue: GraphSet?
}


enum LineChartType {
    case curved
    case line
}

@IBDesignable
class GraphView: UIView {
    
    var lineType: LineChartType = .curved

    @IBInspectable var pointCurveColor: UIColor = .black
    @IBInspectable var lineColor: UIColor = .red
    var arrayElements: [Int] = []
    var chartData: ChartDataModel!
    
    // graph date updated
    public func showGraphWithData(chartData: ChartDataModel) {
        self.chartData = chartData
        self.caluculateXaxisValue(value: chartData.xValue.data)
       
        self.xAxisView.register(UINib(nibName: "XAxisCell", bundle: nil), forCellWithReuseIdentifier: "XAxisCell")
        self.graphView.delegate = self
        self.graphView.chartData = self.chartData
        self.xAxisView.delegate = self
        self.xAxisView.dataSource = self
      
        self.backgroundColor = .white
        self.xAxisView.reloadData()
    }
    
    // Xaxis value
    func caluculateXaxisValue(value: [Int]) {
        arrayElements.removeAll()
        for i in 0..<4 {
            var index = value.count / 4
            index *= i
            arrayElements.append(value[index])
        }
    }
    
    private var xSize: CGFloat {
        self.frame.size.width / CGFloat(arrayElements.count)
    }
    
    lazy var graphView: LineView = {
        let view = LineView()
        view.translatesAutoresizingMaskIntoConstraints = false
       
        view.lineType = self.lineType

        self.baseView.addSubview(view)
        view.isUserInteractionEnabled = true
        
        return view
    }()
    
    lazy var xAxisView: UICollectionView  = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0.0
        layout.minimumInteritemSpacing = 0.0
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        layout.scrollDirection = .horizontal
        
        let collection = UICollectionView(frame: CGRect.zero,collectionViewLayout: layout)
        collection.translatesAutoresizingMaskIntoConstraints = false
        collection.backgroundColor = .white
        collection.setCollectionViewLayout(layout, animated: true)
        self.baseView.addSubview(collection)
        return collection
    }()
    
    
    private lazy var baseScroll: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.showsVerticalScrollIndicator = false
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.backgroundColor = .white
        scrollView.isScrollEnabled = true
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.autoresizingMask = [.flexibleWidth,.flexibleHeight]
        self.addSubview(scrollView)
        return scrollView
    }()
    
    private lazy var baseView: UIView = {
        let view = UIView()
        
        view.translatesAutoresizingMaskIntoConstraints = false
        
        view.backgroundColor = .white
        self.baseScroll.addSubview(view)
        return view
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.baseScroll.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        self.baseScroll.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
        self.baseScroll.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        self.baseScroll.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        
        self.baseView.leadingAnchor.constraint(equalTo: self.baseScroll.leadingAnchor).isActive = true
        self.baseView.trailingAnchor.constraint(equalTo: self.baseScroll.trailingAnchor).isActive = true
        self.baseView.bottomAnchor.constraint(equalTo: self.baseScroll.bottomAnchor).isActive = true
        self.baseView.topAnchor.constraint(equalTo: self.baseScroll.topAnchor).isActive = true
        self.baseView.centerYAnchor.constraint(equalTo: self.baseScroll.centerYAnchor).isActive = true
        self.baseView.centerXAnchor.constraint(equalTo: self.baseScroll.centerXAnchor).isActive = true
        
        self.graphView.topAnchor.constraint(equalTo: self.baseView.topAnchor).isActive = true
        self.graphView.leadingAnchor.constraint(equalTo: self.baseView.leadingAnchor,constant: 0).isActive = true
        self.graphView.trailingAnchor.constraint(equalTo: self.baseView.trailingAnchor,constant: 0).isActive = true
        self.graphView.heightAnchor.constraint(equalTo: self.baseView.heightAnchor, multiplier: 0.9).isActive = true
        
        self.xAxisView.leadingAnchor.constraint(equalTo: self.baseView.leadingAnchor).isActive = true
        self.xAxisView.trailingAnchor.constraint(equalTo: self.baseView.trailingAnchor).isActive = true
        self.xAxisView.bottomAnchor.constraint(equalTo: self.baseView.bottomAnchor).isActive = true
        self.xAxisView.topAnchor.constraint(equalTo: self.graphView.bottomAnchor).isActive = true
        
    }
}



// UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
extension GraphView: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrayElements.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "XAxisCell", for: indexPath) as! XAxisCell
        cell.nameLabel.text = "\(self.arrayElements[indexPath.item])"
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: xSize , height: collectionView.frame.size.height)
    }
    
}



extension GraphView: GraphTouchEventProtocol {
    
    func lineChart(view: LineView, didSelectPoint currentPoint: CGPoint, withAxisSize size: CGSize, events: UIEvent?) {
        
        print(self.chartData.yValue)
        let xPoint =  returnXvalue(x: currentPoint.x, xSize: size.width)
        print("xAxis:\(xPoint)")
        
        let value = returnYvalue(y: currentPoint.y, ySize: size.height)
        print("yAxis:\(value)")
        addToolTipView(currentPoint: currentPoint, selectedPointWith: xPoint, y: Int(value))
        
    }
    
    // Return
    func returnXvalue(x: CGFloat, xSize: CGFloat) -> Int {
        let valueCount = Int(floor(x / xSize)) * calculatePointsSpace(x: chartData.xValue.data.count, y: chartData.yValue.data.count)
        let index = (valueCount > chartData.xValue.data.count - 1) ? chartData.xValue.data.count - 1 : (valueCount > 0) ? valueCount : 0
        return chartData.xValue.data[index]
    }
    
    func returnYvalue(y: CGFloat, ySize: CGFloat) -> CGFloat {
        return ceil((self.graphView.bounds.size.height - y) / ySize)
    }
}

