//
//  ViewController.swift
//  ChartSample
//
//  Created by Vijay on 25/06/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var bigCircle: CircleProgressView!
    @IBOutlet weak var smallCircle: CircleProgressView!
    @IBOutlet weak var graphView: GraphView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        handleAction(index: 0)
        smallCircle.createCiculorPath(bgColor: UIColor.blue.withAlphaComponent(0.3), progressColor:  UIColor.blue, progressValue: 0.3)
      
        bigCircle.createCiculorPath(bgColor:UIColor.red.withAlphaComponent(0.3), progressColor: .red, progressValue: 0.3)

        // Do any additional setup after loading the view.
        
        
    }
    
    @IBAction func segmenrAction(_ sender: UISegmentedControl) {
        handleAction(index: sender.selectedSegmentIndex)
    }
    
    func handleAction(index: Int) {
        if index == 0 {
            var n : [Int] = []
            for i in 0..<20 {
                n.append(i)
            }
            graphView.showGraphWithData(chartData: ChartDataModel(xValue: GraphSet(colors: .orange, data: n, graphDataPoint: .xValue), yValue: GraphSet(colors: UIColor(red:0.20, green:0.80, blue:1.00, alpha:1.0), data: makeList(20),graphDataPoint: .yValue), infoValue: GraphSet(colors: UIColor.red, data: makeList(20), graphDataPoint: .infoValue)))

        } else if index == 1 {
            var n : [Int] = []
            for i in 0..<100 {
                n.append(i)
            }
            graphView.showGraphWithData(chartData: ChartDataModel(xValue: GraphSet(colors: .orange, data: n, graphDataPoint: .xValue), yValue: GraphSet(colors: UIColor(red:0.20, green:0.80, blue:1.00, alpha:1.0), data: makeList(50),graphDataPoint: .yValue), infoValue: GraphSet(colors: UIColor.red, data: makeList(50), graphDataPoint: .infoValue)))
        } else if index == 2 {
            var n : [Int] = []
            for i in 0..<60 {
                n.append(i)
            }
            graphView.showGraphWithData(chartData: ChartDataModel(xValue: GraphSet(colors: .orange, data: n, graphDataPoint: .xValue), yValue: GraphSet(colors: UIColor(red:0.20, green:0.80, blue:1.00, alpha:1.0), data: makeList(30),graphDataPoint: .yValue), infoValue: GraphSet(colors: UIColor.red, data: makeList(30), graphDataPoint: .infoValue)))
        } else {
            var n : [Int] = []
            for i in 0..<60 {
                n.append(i)
            }
            graphView.showGraphWithData(chartData: ChartDataModel(xValue: GraphSet(colors: .orange, data: n, graphDataPoint: .xValue), yValue: GraphSet(colors: UIColor(red:0.20, green:0.80, blue:1.00, alpha:1.0), data: makeList(10),graphDataPoint: .yValue), infoValue: GraphSet(colors: UIColor.red, data: makeList(10), graphDataPoint: .infoValue)))
        }
    }
    
    func makeList(_ n: Int) -> [Int] {
        return (0..<n).map { _ in .random(in: 1...30) }
    }

    
    //, GraphSet(colors: UIColor.darkGray, data: [8,5,6,6,7])
}

