//
//  BottomController.swift
//  ImageUpload
//
//  Created by Vijay on 15/11/19.
//  Copyright © 2019 Vijay. All rights reserved.
//

import UIKit

class BottomController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let alertController = UIAlertController(title: "", message: nil, preferredStyle: .actionSheet)
        if let views: CustomView = CustomView.loadNib(){
            alertController.view.addSubview(views)
            views.table.reloadData()
            views.addConstrins(alertController)
        }
        

        //self.addConstrins(alertController)
        
        
        if alertController.popoverPresentationController != nil {
            
        }
        
        UIApplication.getTopViewController()?.present(alertController, animated: true) {
            // Enabling Interaction for Transperent Full Screen Overlay
            alertController.view.superview?.subviews.first?.isUserInteractionEnabled = true
            // Adding Tap Gesture to Overlay
            
        }
        
        
    }
    
    

    
}



extension UIApplication {
    
    /// Fetch Top Controller from stack
    ///
    /// - Parameter base: Base controller
    /// - Returns: return Top Controller
    class func getTopViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        
        if let nav = base as? UINavigationController {
            return getTopViewController(base: nav.visibleViewController)
            
        } else if let tab = base as? UITabBarController, let selected = tab.selectedViewController {
            return getTopViewController(base: selected)
            
        } else if let presented = base?.presentedViewController {
            return getTopViewController(base: presented)
        }
        return base
    }
}

