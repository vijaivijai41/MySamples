//
//  StreamController.swift
//  ImageUpload
//
//  Created by Vijay on 15/11/19.
//  Copyright © 2019 Vijay. All rights reserved.
//

import UIKit

class StreamController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        switch CommandLine.arguments.dropFirst() {
        case ["client"]: Client.run()
        case ["server"]: Server.run()
        default:
            Client.run()
        }
        
    }
    // Do any additional setup after loading the view.
}

