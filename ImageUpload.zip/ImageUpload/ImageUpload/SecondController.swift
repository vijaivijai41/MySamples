//
//  SecondController.swift
//  ImageUpload
//
//  Created by Vijay on 30/10/19.
//  Copyright © 2019 Vijay. All rights reserved.
//

import UIKit


extension UIView {
    
    func rotateAnimation(duration: CFTimeInterval = 2.0, rotateValue: CGFloat) {
        let rotateAnimation = CABasicAnimation(keyPath: "transform.rotation")
        rotateAnimation.fromValue = 0.0
        rotateAnimation.toValue = CGFloat(.pi * rotateValue)
        rotateAnimation.duration = duration
        rotateAnimation.repeatCount = .infinity
        self.layer.add(rotateAnimation, forKey: nil)
    }
}

class Cell: UITableViewCell {
    
    @IBOutlet weak var imag: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       // imag.rotateAnimation(rotateValue: 20)
    }
    
    
}

class SecondController: UIViewController ,UITableViewDelegate , UITableViewDataSource {
    var shownIndexes : [IndexPath] = []
    let CELL_HEIGHT : CGFloat = 40
    
    var arrays: [String] = ["vijay","kumar","mss","vijay1","kumar1","ms1s", "ndd3","kumar2","mss2","afef"]
    var dublicateArray: [String] = [String]()
    var isFirsttime = false
    
    @IBOutlet weak var table: UITableView!
    var rotateValue: CGFloat = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dublicateArray = arrays
        // Do any additional setup after loading the view.
    }
    @IBAction func refresh(_ sender: UIBarButtonItem) {
        shownIndexes = [IndexPath]()
        dublicateArray = [String]()
//        if !isFirsttime {
//            for i in 0...10 {
//                let indexPath = IndexPath(item: Int(i), section: 0)
//                shownIndexes.append(indexPath)
//            }
//
//            isFirsttime = true
//            table.insertRows(at: shownIndexes, with: .automatic)
//        } else {
            
            let randomArray = (0...9).shuffled()
            for i in randomArray {
                let indexPath = IndexPath(item: Int(i), section: 0)
                shownIndexes.append(indexPath)
                dublicateArray.append(arrays[indexPath.row])
            }
            arrays = dublicateArray
        //table.reloadData()
        table.reloadRows(at: shownIndexes, with: .automatic)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrays.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! Cell
        cell.textLabel?.text = arrays[indexPath.row]
      //  cell.imag.startAnimating()
       // shownIndexes.append(indexPath)
        return cell
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.table.reloadInputViews()
    }
    
    
    func scrollViewDidChangeAdjustedContentInset(_ scrollView: UIScrollView) {
        rotateValue = scrollView.adjustedContentInset.bottom
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
       
    }
}


extension Array {
    func rand() -> Element? {
        if self.isEmpty { return nil }
        let randomInt = Int(arc4random_uniform(UInt32(self.count)))
        return self[randomInt]
    }
}



extension SecondController: StreamDelegate {
    
    
    
}
