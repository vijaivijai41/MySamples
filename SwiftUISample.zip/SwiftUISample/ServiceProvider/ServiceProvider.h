//
//  ServiceProvider.h
//  ServiceProvider
//
//  Created by Vijay on 19/08/20.
//

#import <Foundation/Foundation.h>

//! Project version number for ServiceProvider.
FOUNDATION_EXPORT double ServiceProviderVersionNumber;

//! Project version string for ServiceProvider.
FOUNDATION_EXPORT const unsigned char ServiceProviderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ServiceProvider/PublicHeader.h>


