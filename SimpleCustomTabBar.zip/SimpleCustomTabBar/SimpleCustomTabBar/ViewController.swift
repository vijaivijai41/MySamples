//
//  ViewController.swift
//  SimpleCustomTabBar
//
//  Created by Vijay on 19/08/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}

