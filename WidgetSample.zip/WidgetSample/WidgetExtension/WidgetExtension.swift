//
//  WidgetExtension.swift
//  WidgetExtension
//
//  Created by Vijay on 06/08/20.
//

import WidgetKit
import SwiftUI
import Intents
import Services

let GROUPDEFAULT = UserDefaults.init(suiteName: "group.myGroup.Sample")

struct Provider: IntentTimelineProvider {
    
    public func snapshot(for configuration: ConfigurationIntent, with context: Context, completion: @escaping (ImageEntry) -> ()) {
        
        var id = ""
        if let userSelection = GROUPDEFAULT?.string(forKey: "SelectedNumber"){
            id = userSelection
        } else {
            id = "1"
        }
        
        WidgetCenter.shared.reloadAllTimelines()
        WebCall.imagesFetch(id: id) { (result) in
            let serverData: ImageModel
            
            if case .success(let fetchedServerData) = result {
                serverData = fetchedServerData
            } else {
                serverData = ImageModel(id: 1, title: "This is sample title")
                print ("Please set a server for widget")
            }
            
            let entry =  ImageEntry(date: Date(), images: serverData, configuration: configuration)
            completion(entry)
        }
    }

    func timeline(for configuration: ConfigurationIntent, with context: Context, completion: @escaping (Timeline<ImageEntry>) -> ()) {
        
        let currentDate = Date()
        let refreshDate = Calendar.current.date(byAdding: .minute, value: 1, to: currentDate)!
        var id = ""
        if let userSelection = GROUPDEFAULT?.string(forKey: "SelectedNumber"){
            id = userSelection
        } else {
            id = "1"
        }
        
        WebCall.imagesFetch(id: id) { (result) in
            let serverData: ImageModel
            
            if case .success(let fetchedServerData) = result {
                serverData = fetchedServerData
            } else {
                serverData = ImageModel(id: 1, title: "This is sample title")
                print ("Please set a server for widget")
            }
            
            let entry =  ImageEntry(date: Date(), images: serverData, configuration: configuration)
            let timeline = Timeline(entries: [entry], policy: .after(refreshDate))
            completion(timeline)
        }

    }
    
}



struct WebCall {
    
    static func imagesFetch(id: String, onCompletion: @escaping(Result<ImageModel, ErrorHandler>) ->()){
        let repository: Repository = Repository(dataStore: DataStore.shared, apiHandler: WebserviceHandler())
        let resource = DataNetworkResource.fetchList(id: id)
        repository.fetchAnimalImage(resource: resource, onCompletion: onCompletion)
    }
}

struct ImageEntry: TimelineEntry {
    var date: Date
    public let images: ImageModel?
    public let configuration: ConfigurationIntent
}

struct PlaceholderView : View {
    var body: some View {
        Text("Placeholder View")
    }
}

struct WidgetExtensionEntryView : View {
    var entry: Provider.Entry

    var body: some View {
        ZStack {
            Text(entry.images?.title ?? "")
                .font(.callout)
                .padding(10)
                .foregroundColor(.white)
        }.background(Color.green)
        .opacity(0.8)
        .cornerRadius(10.0)
        .padding(10)
    }
}

@main
struct WidgetExtension: Widget {
    private let kind: String = "WidgetExtension"

    public var body: some WidgetConfiguration {
        IntentConfiguration(kind: kind, intent: ConfigurationIntent.self, provider: Provider(), placeholder: PlaceholderView()) { entry in
            WidgetExtensionEntryView(entry: entry)
        }
        .configurationDisplayName("My Widget")
        .description("This is an example widget.")
    }
}

struct WidgetExtension_Previews: PreviewProvider {
    static var previews: some View {
        WidgetExtensionEntryView(entry: ImageEntry(date: Date(), images: nil, configuration: ConfigurationIntent()))
            .previewContext(WidgetPreviewContext(family: .systemSmall))
    }
}
